package kr.co.ezen.entity;

import lombok.Data;

@Data
public class Criteria {
	
	private String search;
	private int stuIdx;
}
