package kr.co.ezen.entity;

import lombok.Data;

@Data
public class Student {
	private int stuIdx;
	private String stuName;
	private String stuAddr;
	private String stuSchool;
	private String stuDept;
}
